import express from "express";
import db from "../db/config.js";
import { ObjectId } from "mongodb";

const router = express.Router();
// return first 50 documents from movies collection
router.get("/", async (req, res) => {
    let results = await db.collection('movies').find({})
    .limit(50)
    .toArray();
    res.send(results).status(200);
});

//--------------------------------------------------------------------------------------------------------
// Add a new movie document to the movies collection
router.post("/", async (req, res) => {
    try {
      const newMovies = req.body; 
  
      // Check if the input is an array and contains at least one movie.
      if (!Array.isArray(newMovies) || newMovies.length === 0) {
        return res.status(400).send({ error: "Please provide at least one movie in the request body." });
      }
  
      const result = await db.collection('movies').insertMany(newMovies);
      res.status(201).send(result.ops); // Send back the new movie documents that were added to the collection
    } catch (error) {
      console.error(error);
      res.status(500).send({ error: "An error occurred while trying to create new movies" });
    }
  });

//--------------------------------------------------------------------------------------------------------
// return a movie by its _id with average score and comments
router.get("/:id", async (req, res) => {
  try {
    const id = req.params.id; // Extracting the id from the route parameters
    /*
        // Check if the provided id is a valid ObjectId
        if (!ObjectId.isValid(id)) {
          return res.status(400).send({ error: "Invalid ID provided" });
        }
    
        const _id = new ObjectId(id); // Create an ObjectId
    */
    // Check if the provided id is valid
    if (!id) {
      return res.status(400).send({ error: "Invalid ID provided" });
    }
    const _id = parseInt(id);
    const pipeline = [
      { $unwind: "$movies" }, // First, unwind the movies array
      { $match: { "movies.movieid": _id } },
      { $group: {
        _id: "$movies.movieid", avg_score: {$avg: "$movies.rating"}
        }
      },
      { $lookup: {
        from: "movies",
        localField: "_id",
        foreignField: "_id",
        as: "movies" 
      }},
      { $lookup: {
          from: "comments",
          localField: "_id",
          foreignField: "movie_id",
          as: "comments" 
      }},
      { $project: {
        _id: 1,
        title: { $arrayElemAt: ["$movies.title", 0] },
        genres: "$movies.genres",
        year: { $arrayElemAt: ["$movies.year", 0] },
        avg_score: 1,
        comments: "$comments.comment"
    }},
    ];

      const result = await db.collection('users').aggregate(pipeline).toArray();

      if (result.length === 0) {
          return res.status(404).send({ message: "No movies found for the given movie ID." });
      }
      
      res.status(200).send(result);
  
    } catch (error) {
      console.error(error);
      res.status(500).send({ error: "An error occurred while retrieving the movie." });
  }
});


//--------------------------------------------------------------------------------------------------------
//delete a movie by _id
router.delete("/:id", async (req, res) => {
    try {
      const id = req.params.id; // Extracting the id from the route parameters
  /*
      // Check if the provided id is a valid ObjectId
      if (!ObjectId.isValid(id)) {
        return res.status(400).send({ error: "Invalid ID provided" });
      }
  
      const _id = new ObjectId(id); // Create an ObjectId
  */
      // Check if the provided id is valid
      if (!id) {
        return res.status(400).send({ error: "Invalid ID provided" });
      }
      const _id = parseInt(id);
      const result = await db.collection('movies').deleteOne({ _id: _id });
  
      // Check if any document was deleted
      if (result.deletedCount === 0) {
        return res.status(404).send({ error: "No movie found to delete" });
      }
  
      res.status(200).send({ success: true, message: "Movie successfully deleted" });
    } catch (error) {
      console.error(error);
      res.status(500).send({ error: "An error occurred while deleting the movie" });
    }
  });

export default router;