import express from "express";
import db from "../db/config.js";
import { ObjectId } from "mongodb";

const router = express.Router();
// return first 50 documents from movies collection
router.get("/", async (req, res) => {
    let results = await db.collection('movies').find({})
    .limit(50)
    .toArray();
    res.send(results).status(200);
});

//--------------------------------------------------------------------------------------------------------
// Add a new movie document to the movies collection
router.post("/", async (req, res) => {
    try {
      const newMovies = req.body; 
  
      // Check if the input is an array and contains at least one movie.
      if (!Array.isArray(newMovies) || newMovies.length === 0) {
        return res.status(400).send({ error: "Please provide at least one movie in the request body." });
      }
  
      const result = await db.collection('movies').insertMany(newMovies);
      res.status(201).send(result.ops); // Send back the new movie documents that were added to the collection
    } catch (error) {
      console.error(error);
      res.status(500).send({ error: "An error occurred while trying to create new movies" });
    }
  });

//--------------------------------------------------------------------------------------------------------
// return a movie by its _id with average score and comments
router.get("/:id", async (req, res) => {
  try {
    const id = req.params.id;
/*
     // Check if the provided id is a valid ObjectId
    if (!ObjectId.isValid(id)) {
       return res.status(400).send({ error: "Invalid ID provided" });
    }
  
     const _id = new ObjectId(id); // Create an ObjectId
*/
      // Check if the provided id is valid
    if (!id) {
      return res.status(400).send({ error: "Invalid ID provided" });
     }
    const _id = parseInt(id);
    
    // Find the movie by its ID
    const movie = await db.collection('movies').findOne({ _id: _id });

    if (!movie) {
      return res.status(404).send({ error: "Movie not found" });
    }

    // Get all users who have rated this movie
    const usersWithRating = await db.collection('users').find({
      "movies": {
        $elemMatch: { "movieid": _id }
      }
    }).toArray();

    // Retrieve comments for the movie
    const comments = await db.collection('comments').find({ movie_id: _id }).toArray();    

    if (usersWithRating.length === 0) {
      return res.status(200).send({
        ...movie,
        avg_score: 0, // No ratings found, so average is 0
        comments: comments
      });
    }

    let totalRating = 0;
    let numRatings = 0;

    // Iterate through users and their movies to calculate the average rating
    for (const user of usersWithRating) {
      for (const userMovie of user.movies) {
        if (userMovie.movieid === _id) {
          totalRating += userMovie.rating;
          numRatings++;
        }
      }
    }

    const avg_score = totalRating / numRatings;

    res.status(200).send({
      ...movie,
      avg_score: avg_score,
      comments: comments
    });
  } catch (error) {
    console.error(error);
    res.status(500).send({ error: "An error occurred while retrieving the movie" });
  }
});

//--------------------------------------------------------------------------------------------------------
//delete a movie by _id
router.delete("/:id", async (req, res) => {
    try {
      const id = req.params.id; // Extracting the id from the route parameters
  /*
      // Check if the provided id is a valid ObjectId
      if (!ObjectId.isValid(id)) {
        return res.status(400).send({ error: "Invalid ID provided" });
      }
  
      const _id = new ObjectId(id); // Create an ObjectId
  */
      // Check if the provided id is valid
      if (!id) {
        return res.status(400).send({ error: "Invalid ID provided" });
      }
      const _id = parseInt(id);
      const result = await db.collection('movies').deleteOne({ _id: _id });
  
      // Check if any document was deleted
      if (result.deletedCount === 0) {
        return res.status(404).send({ error: "No movie found to delete" });
      }
  
      res.status(200).send({ success: true, message: "Movie successfully deleted" });
    } catch (error) {
      console.error(error);
      res.status(500).send({ error: "An error occurred while deleting the movie" });
    }
  });

export default router;