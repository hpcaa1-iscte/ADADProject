import express from "express";
import db from "../db/config.js";
import { ObjectId } from "mongodb";

const router = express.Router();
// return first 50 documents from movies collection
router.get("/", async (req, res) => {
  let results = await db.collection('users').find({})
  .limit(50)
  .toArray();
res.send(results).status(200);
});

//--------------------------------------------------------------------------------------------------------
// Add new user documents to the users collection
router.post("/", async (req, res) => {
    try {
      const newUsers = req.body; // Here, we expect req.body to be an array of user objects.
  
      // Check if the input is an array and contains at least one user.
      if (!Array.isArray(newUsers) || newUsers.length === 0) {
        return res.status(400).send({ error: "Please provide at least one user in the request body." });
      }
  
      // TODO: Add validation for user data here.
  
      const result = await db.collection('users').insertMany(newUsers);
      res.status(201).send(result.ops); // Send back the new user documents that were added to the collection
    } catch (error) {
      console.error(error);
      res.status(500).send({ error: "An error occurred while trying to create new users" });
    }
  });

//--------------------------------------------------------------------------------------------------------
// Return a user from the users collection by its _id, include in the response the top 5 scored movie of the user
  router.get("/:id", async (req, res) => {
    try {
      const id = req.params.id; // Extracting the id from the route parameters
      /*
          // Check if the provided id is a valid ObjectId
          if (!ObjectId.isValid(id)) {
            return res.status(400).send({ error: "Invalid ID provided" });
          }
      
          const _id = new ObjectId(id); // Create an ObjectId
      */
      // Check if the provided id is valid
      if (!id) {
        return res.status(400).send({ error: "Invalid ID provided" });
      }
      const _id = parseInt(id);
      const pipeline = [
        { $match: { "_id": _id } },
        { $group: {
          _id: "$movies.movieid", avg_score: {$avg: "$movies.rating"}
          }
        },
        { $lookup: {
          from: "movies",
          localField: "_id",
          foreignField: "_id",
          as: "movies" 
        }},
        { $lookup: {
            from: "comments",
            localField: "_id",
            foreignField: "movie_id",
            as: "comments" 
        }},
        { $project: {
          _id: 1,
          title: { $arrayElemAt: ["$movies.title", 0] },
          genres: "$movies.genres",
          year: { $arrayElemAt: ["$movies.year", 0] },
          avg_score: 1,
          comments: "$comments.comment"
      }},
      ];
  
        const result = await db.collection('users').aggregate(pipeline).toArray();
  
        if (result.length === 0) {
            return res.status(404).send({ message: "No movies found for the given movie ID." });
        }
        
        res.status(200).send(result);
    
      } catch (error) {
        console.error(error);
        res.status(500).send({ error: "An error occurred while retrieving the movie." });
    }
  });

// Endpoint to delete a user by _id
router.delete("/user/:id", async (req, res) => {
    try {
/*
      // Check if the provided id is a valid ObjectId
      if (!ObjectId.isValid(id)) {
        return res.status(400).send({ error: "Invalid ID provided" });
      }
        
     const _id = new ObjectId(id); // Create an ObjectId
*/
      // Check if the provided id is valid
      if (!id) {
        return res.status(400).send({ error: "Invalid ID provided" });
      }
      const _id = parseInt(id);
      const result = await db.collection('users').deleteOne({ _id: _id });
  
      // Check if any document was deleted
      if (result.deletedCount === 0) {
        return res.status(404).send({ error: "No user found to delete" });
      }
  
      res.status(200).send({ success: true, message: "User successfully deleted" });
    } catch (error) {
      console.error(error);
      res.status(500).send({ error: "An error occurred while deleting the user" });
    }
  });
  
export default router;